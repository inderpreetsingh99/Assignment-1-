﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Airline_Reservation
{
    public partial class Form1 : Form
    {
        
        string[,] s = new string[5, 3];
        
        string[] wait = new string[10];


        public Form1()
        {
            InitializeComponent();
        }

        
        private void button17_Click(object sender, EventArgs e)
        {
           

            

        }


       
        private void button21_Click(object sender, EventArgs e)
        {

           
        }


      
        private void button18_Click(object sender, EventArgs e)
        {

            if (textBox1.Text == "")
            {
                MessageBox.Show("Please enter the name of passenger.");
                MessageBox.Show("Available");
            }
            else
            {
                MessageBox.Show("Your ticket is booked.");
            }
            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 0)
            {
                s[0, 0] = textBox1.Text;
            }
            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 1)
            {
                s[0, 1] = textBox1.Text;
            }

            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 2)
            {
                s[0, 2] = textBox1.Text;
            }
            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 0)
            {
                s[1, 0] = textBox1.Text;
            }
            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 1)
            {
                s[1, 1] = textBox1.Text;
            }
            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 2)
            {
                s[1, 2] = textBox1.Text;
            }
            if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 0)
            {
                s[2, 0] = textBox1.Text;
            }
            if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 1)
            {
                s[2, 1] = textBox1.Text;
            }
            if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 2)
            {
                s[2, 2] = textBox1.Text;
            }
            if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 0)
            {
                s[3, 0] = textBox1.Text;
            }
            if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 1)
            {
                s[3, 1] = textBox1.Text;
            }
            if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 2)
            {
                s[3, 2] = textBox1.Text;
            }
            if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 0)
            {
                s[4, 0] = textBox1.Text;
            }
            if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 1)
            {
                s[4, 1] = textBox1.Text;
            }
            if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 2)
            {
                s[4, 2] = textBox1.Text;
            }


        }


        //Fill All button
        private void button22_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    s[i, j] = "Already reserved" + "\n";
                }
            }
        }


       
        private void button16_Click(object sender, EventArgs e)
        {

            richTextBox1.Text = "";

            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    richTextBox1.Text += s[i, j];
                }
            }
        }


       
        private void button19_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 0)
            {
                s[0, 0] = "";
                MessageBox.Show("Ticket Cancled.");
            }
            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 1)
            {
                s[0, 1] = "";
                MessageBox.Show("Ticket Cancled.");
            }

            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 2)
            {
                s[0, 2] = "";
                MessageBox.Show("Ticket Cancled.");
            }
            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 0)
            {
                s[1, 0] = "";
                MessageBox.Show("Ticket Cancled.");
            }
            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 1)
            {
                s[1, 1] = "";
                MessageBox.Show("Ticket Cancled.");
            }
            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 2)
            {
                s[1, 2] = "";
                MessageBox.Show("Ticket Cancled.");
            }
            if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 0)
            {
                s[2, 0] = "";
                MessageBox.Show("Ticket Cancled.");
            }
            if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 1)
            {
                s[2, 1] = "";
                MessageBox.Show("Ticket Cancled.");
            }
            if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 2)
            {
                s[2, 2] = "";
                MessageBox.Show("Ticket Cancled.");
            }
            if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 0)
            {
                s[3, 0] = "";
                MessageBox.Show("Ticket Cancled.");
            }
            if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 1)
            {
                s[3, 1] = "";
                MessageBox.Show("Ticket Cancled.");
            }
            if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 2)
            {
                s[3, 2] = "";
                MessageBox.Show("Ticket Cancled.");
            }
            if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 0)
            {
                s[4, 0] = "";
                MessageBox.Show("Ticket Cancled.");
            }
            if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 1)
            {
                s[4, 1] = "";
                MessageBox.Show("Ticket Cancled.");
            }
            if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 2)
            {
                s[4, 2] = "";
                MessageBox.Show("Ticket Cancled.");
            }
        }

        private void button20_Click(object sender, EventArgs e)
        {
          

        }



        
        

        

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
